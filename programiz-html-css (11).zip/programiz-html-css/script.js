function selesai(waktu) {
  const pesan = document.getElementById("pesan");
  pesan.innerHTML = `🎉 Selamat! Anda sudah menyelesaikan ${waktu} hari ini.`;
}
